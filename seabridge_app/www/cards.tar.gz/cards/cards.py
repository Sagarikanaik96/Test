# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# MIT License. See license.txt

from __future__ import unicode_literals
import frappe

sitemap = 1

def get_context(context):
	context.data = [{ "invoice":"INV-20-02011", "supplier":"Raj Plumbers","due_date":"12-Jan-2021", "amt":165.23, "status" : "Approved" },{ "invoice":"INV-20-02211", "supplier":"United Electricals","due_date":"14-Jan-2021", "amt":2002.00, "status" : "Submitted" }]
	return context
